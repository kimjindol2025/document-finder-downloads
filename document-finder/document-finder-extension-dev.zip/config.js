"use strict";
const DF_CONFIG = {"origins": ["http://127.0.0.1:30081", "https://kimjindol2025.github.io"], "development": true};
