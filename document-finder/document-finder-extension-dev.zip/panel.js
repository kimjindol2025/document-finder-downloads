"use strict";
const $ = selector => document.querySelector(selector);
function text(tag, value, className = "") { const node = document.createElement(tag); node.textContent = value; node.className = className; return node; }
const port = chrome.runtime.connect({ name: "document-finder-private" });
const requests = new Map(); let sequence = 0, connected = false, timer, pollTimer, searching = 0, documents = [], current = null, offset = 0, initialReady = false, wasBusy = false;
function rpc(op, params = {}) {
  return new Promise((resolve, reject) => {
    const id = String(++sequence), timeout = setTimeout(() => { requests.delete(id); reject(new Error("RESPONSE_TIMEOUT")); }, 45000);
    requests.set(id, { resolve, reject, timeout }); port.postMessage({ id, op, params });
  });
}
const errors = { HOST_UNAVAILABLE:"검색기를 찾지 못했습니다. 설치 상태와 다른 창의 연결을 확인하세요.", SESSION_REQUIRED:"이 컴퓨터 연결을 다시 승인해 주세요.", NO_FOLDERS:"먼저 색인할 폴더를 선택하세요.", CONSENT_DENIED:"로컬 승인 창에서 취소했습니다.", INDEX_SWITCHING:"검색 범위를 바꾸고 있습니다. 잠시 후 다시 시도하세요.", IndexPending:"색인 중입니다. 완료 후 검색 결과를 표시합니다.", INDEX_BUSY:"현재 색인 작업이 끝난 후 다시 시도하세요.", ORIGIN_NOT_ALLOWED:"허용되지 않은 서비스 주소입니다.", REQUEST_BUSY:"처리 중인 요청이 많습니다. 잠시 후 다시 시도하세요.", DOCUMENT_NOT_FOUND:"문서를 찾을 수 없거나 접근할 수 없습니다.", DIALOG_UNAVAILABLE:"운영체제의 승인·폴더 선택 창을 열지 못했습니다." };
function message(error = "") { $("#message").textContent = errors[error.message] || error.message || error; }
port.onMessage.addListener(reply => {
  const pending = requests.get(reply.id); if (!pending) return;
  clearTimeout(pending.timeout); requests.delete(reply.id);
  reply.ok ? pending.resolve(reply.result) : pending.reject(new Error(reply.error?.code || "REQUEST_FAILED"));
});
port.onDisconnect.addListener(() => {
  openSequence++; searching++; clearTimeout(timer);
  connected = false; clearTimeout(pollTimer); $("#connection").textContent = "로컬 연결 끊김";
  $("#workspace").hidden = true; $("#viewer").hidden = true; $("#document-body").replaceChildren(); $("#results").replaceChildren(); documents = []; current = null;
  for (const pending of requests.values()) { clearTimeout(pending.timeout); pending.reject(new Error("HOST_UNAVAILABLE")); } requests.clear();
});
function siteOrigin() {
  const parent = location.ancestorOrigins?.[0];
  if (parent && DF_CONFIG.origins.includes(parent)) return parent;
  if (window.top === window) return DF_CONFIG.origins[0];
  throw new Error("ORIGIN_NOT_ALLOWED");
}
async function connect() {
  $("#connect").disabled = true; message("로컬 승인 창을 확인하세요.");
  try {
    const state = await rpc("connect", { origin: siteOrigin() }); connected = true;
    $("#connection").textContent = "이 컴퓨터 연결됨"; $("#disconnect").disabled = false;
    $("#workspace").hidden = false; message(""); showStatus(state); await poll();
  } catch (error) { message(error); } finally { $("#connect").disabled = false; }
}
function showStatus(state) {
  const stats = state.stats || {}, progress = state.progress || {};
  $("#status").textContent = state.rebuilding ? "전체 색인을 새 DB로 만들고 있습니다. 기존 검색을 유지합니다." : state.indexing
    ? "색인 중 · " + (progress.documents || 0).toLocaleString() + "개 발견" + (state.ready ? " · 이전 목록 사용 가능" : "")
    : !state.roots.length ? "이 컴퓨터의 문서를 색인할까요? 아래 폴더 선택 버튼으로 범위를 정하세요."
    : (stats.documents || 0).toLocaleString() + "개 문서 · 원본 읽음 " + (stats.files_read || 0) + " / 건너뜀 " + (stats.files_skipped || 0) + " · 마지막 성공 " + (stats.indexed_at ? new Date(stats.indexed_at * 1000).toLocaleString() : "아직 없음") + (state.search_ms != null ? " · 최근 검색 " + state.search_ms + "ms" : "");
  $("#diagnostics").textContent = JSON.stringify({ index_error: state.index_error || "", rebuild_error: state.rebuild_error || "", documents: stats.documents || 0, excluded: stats.exclusions || {}, database_bytes: state.catalog_bytes || 0 }, null, 2);
  $("#roots").replaceChildren();
  for (const root of state.roots) {
    const row = text("div", "", "root"), remove = text("button", "이 폴더 제외");
    remove.addEventListener("click", async () => { try { const next = await rpc("remove_folder", { path: root }); documents = []; renderResults(); showStatus(next); initialReady = false; await poll(); } catch (error) { message(error); } });
    row.append(text("span", root), remove); $("#roots").append(row);
  }
  $("#refresh").disabled = state.indexing || !state.roots.length;
  $("#rebuild").disabled = state.indexing || state.rebuilding || !state.roots.length;
  if (document.activeElement !== $("#minutes")) $("#minutes").value = (state.refresh_seconds || 600) / 60;
  if (state.index_error || state.rebuild_error) message(state.index_error || state.rebuild_error);
}
async function poll() {
  clearTimeout(pollTimer); if (!connected) return;
  try {
    const state = await rpc("status"); showStatus(state);
    const busy = state.indexing || state.rebuilding, completed = wasBusy && !busy; wasBusy = busy;
    if (state.ready && (!initialReady || completed)) { initialReady = true; await search(); }
    pollTimer = setTimeout(poll, state.indexing || state.rebuilding ? 1000 : 10000);
  } catch (error) { message(error); pollTimer = setTimeout(poll, 5000); }
}
function renderResults() {
  $("#results").replaceChildren();
  for (const doc of documents) {
    const button = text("button", "", "result");
    button.append(text("span", doc.project, "project"), text("strong", doc.title), text("small", doc.path), text("small", new Date(doc.modified * 1000).toLocaleString()));
    button.addEventListener("click", () => openDocument(doc.id)); $("#results").append(button);
  }
}
async function search(append = false) {
  const request = ++searching;
  $("#count").textContent = "검색 중…"; message("");
  try {
    const result = await rpc("search", { query: $("#query").value, project: $("#project").value, sort: $("#sort").value, offset: append ? offset : 0, limit: 30 });
    if (request !== searching || !connected) return;
    documents = append ? documents.concat(result.documents) : result.documents; offset = result.next_offset;
    $("#count").textContent = result.matched.toLocaleString() + "개 일치 · " + result.search_ms + "ms";
    $("#more").hidden = !result.has_more;
    const project = $("#project").value; $("#project").replaceChildren();
    const all = text("option", "모든 프로젝트"); all.value = ""; $("#project").append(all);
    for (const item of result.projects) { const option = text("option", item.name + " (" + item.count + ")"); option.value = item.name; $("#project").append(option); }
    $("#project").value = project; renderResults();
    if (!result.matched) message("일치하는 제목·경로가 없습니다. 본문은 검색하지 않습니다.");
  } catch (error) { if (request === searching) { $("#count").textContent = "검색을 완료하지 못했습니다"; message(error); } }
}
function renderDocument(body) {
  // Bounded DOM-only Markdown subset; no HTML, scripts or remote images.
  const fragment = document.createDocumentFragment(); let code = null, codeLines = [];
  for (const line of body.split(/\r?\n/)) {
    if (/^\s*```/.test(line)) { if (code) { code.textContent = codeLines.join("\n"); code = null; codeLines = []; } else { code = text("pre", ""); fragment.append(code); } continue; }
    if (code) { codeLines.push(line); continue; }
    const heading = /^(#{1,6})\s+(.*)$/.exec(line);
    if (heading) fragment.append(text("h" + heading[1].length, heading[2]));
    else if (line.trim()) fragment.append(text("p", line));
  }
  if (code) code.textContent = codeLines.join("\n");
  return fragment;
}
let openSequence = 0;
async function openDocument(id) {
  const request = ++openSequence;
  try {
    const result = await rpc("read_document", { document_id: id }); let body = "", at = 0;
    while (at < result.characters) {
      const chunk = await rpc("read_chunk", { handle: result.handle, offset: at });
      if (request !== openSequence) return;
      if (chunk.next_offset <= at) throw new Error("INVALID_CHUNK");
      body += chunk.text; at = chunk.next_offset;
    }
    if (request !== openSequence || !connected) return;
    current = result.document;
    $("#document-title").textContent = current.title; $("#document-path").textContent = current.path;
    $("#document-body").replaceChildren(current.format === "TXT" ? text("pre", body) : renderDocument(body));
    $("#viewer").hidden = false; $("#workspace").hidden = true; history.pushState({ document: id }, ""); message("");
  } catch (error) { message(error); }
}
function back() { openSequence++; current = null; $("#viewer").hidden = true; $("#workspace").hidden = !connected; }
$("#connect").addEventListener("click", connect);
$("#disconnect").addEventListener("click", async () => { try { await rpc("disconnect"); connected = false; searching++; clearTimeout(timer); back(); clearTimeout(pollTimer); documents = []; $("#results").replaceChildren(); $("#document-body").replaceChildren(); $("#connection").textContent = "연결 승인을 철회했습니다"; $("#disconnect").disabled = true; } catch (error) { message(error); } });
$("#choose-folder").addEventListener("click", async () => { try { message("운영체제의 폴더 선택 창을 확인하세요."); await rpc("choose_folder"); initialReady = false; message(""); await poll(); } catch (error) { message(error); } });
$("#refresh").addEventListener("click", async () => { try { await rpc("refresh"); initialReady = false; await poll(); } catch (error) { message(error); } });
$("#rebuild").addEventListener("click", async () => { try { await rpc("rebuild"); await poll(); } catch (error) { message(error); } });
$("#search-form").addEventListener("submit", event => { event.preventDefault(); clearTimeout(timer); search(); });
$("#query").addEventListener("input", () => { clearTimeout(timer); searching++; timer = setTimeout(search, 450); });
$("#project").addEventListener("change", () => search()); $("#sort").addEventListener("change", () => search());
$("#more").addEventListener("click", () => search(true));
$("#back").addEventListener("click", () => { back(); history.back(); }); window.addEventListener("popstate", back);
$("#settings-toggle").addEventListener("click", () => { $("#settings").hidden = !$("#settings").hidden; });
$("#save-interval").addEventListener("click", async () => { try { await rpc("set_interval", { seconds: Number($("#minutes").value) * 60 }); message("저장했습니다."); } catch (error) { message(error); } });
$("#diagnose").addEventListener("click", async () => { try { const value = await rpc("diagnose", { path: $("#diagnostic-path").value }); const labels = { indexed:"색인됨", pending_update:"아직 갱신 전", excluded:"제외 규칙에 해당", permission_denied:"현재 사용자 권한으로 읽을 수 없음", outside_scope:"검색 허용 범위 밖", missing:"경로 없음" }; $("#diagnostic-result").textContent = labels[value.state] || value.state; } catch (error) { message(error); } });
$("#export-diagnostics").addEventListener("click", async () => { try { const value = await rpc("export_diagnostics"); message(value.canceled ? "저장을 취소했습니다." : "진단 파일 저장: " + value.path); } catch (error) { message(error); } });
for (const [selector, op] of [["#open-original", "open_original"], ["#reveal", "reveal"]]) $(selector).addEventListener("click", async () => { if (current) try { await rpc(op, { document_id: current.id }); } catch (error) { message(error); } });
$("#copy-path").addEventListener("click", async () => { if (current) try { await navigator.clipboard.writeText(current.path); message("경로를 복사했습니다."); } catch (_) { message("경로를 선택해 직접 복사해 주세요."); } });
window.addEventListener("pagehide", () => { clearTimeout(pollTimer); clearTimeout(timer); port.disconnect(); });
