"use strict";
importScripts("config.js");
const origins = new Set(DF_CONFIG.origins);
const own = chrome.runtime.getURL("");
function webAllowed(sender) {
  try { return origins.has(new URL(sender.url).origin); } catch (_) { return false; }
}
chrome.runtime.onMessageExternal.addListener((request, sender, respond) => {
  if (!webAllowed(sender) || request?.type !== "discover" || request.protocol !== 1) return;
  respond({ protocol: 1, installed: true, version: chrome.runtime.getManifest().version,
            panel: chrome.runtime.getURL("panel.html") });
});
chrome.action.onClicked.addListener(() => chrome.tabs.create({ url: chrome.runtime.getURL("panel.html") }));
chrome.runtime.onConnect.addListener(port => {
  let url;
  try { url = new URL(port.sender?.url); } catch (_) { port.disconnect(); return; }
  if (url.href.split("?")[0].split("#")[0] !== own + "panel.html" || port.name !== "document-finder-private") {
    port.disconnect(); return;
  }
  let native = null, session = "";
  const pending = new Set();
  function disconnected() {
    session = "";
    for (const id of pending) port.postMessage({ id, ok: false, error: { code: "HOST_UNAVAILABLE" } });
    pending.clear(); native = null;
  }
  port.onMessage.addListener(request => {
    if (!request || typeof request.id !== "string" || request.id.length > 64 || pending.size >= 4 || pending.has(request.id)) {
      port.postMessage({ id: request?.id || "", ok: false, error: { code: "REQUEST_BUSY" } }); return;
    }
    if (request.op === "connect" && !origins.has(request.params?.origin)) {
      port.postMessage({ id: request.id, ok: false, error: { code: "ORIGIN_NOT_ALLOWED" } }); return;
    }
    if (!native) {
      native = chrome.runtime.connectNative("kr.dclub.document_finder");
      native.onDisconnect.addListener(() => { void chrome.runtime.lastError; disconnected(); });
      native.onMessage.addListener(reply => {
        if (!pending.has(reply.id)) return;
        pending.delete(reply.id);
        if (reply.ok && reply.result?.session) {
          session = reply.result.session;
          reply = { ...reply, result: reply.result.status };
        }
        if (reply.ok && reply.result?.disconnected) session = "";
        port.postMessage(reply);
      });
    }
    pending.add(request.id);
    try { native.postMessage({ protocol: 1, id: request.id, op: request.op, params: request.params || {}, session }); }
    catch (_) { disconnected(); }
  });
  port.onDisconnect.addListener(() => { pending.clear(); native?.disconnect(); session = ""; });
});
